# Zoomer

# What's Zoomer

Zoomer is an opensource and cross-platform face recognition lib for python

# How to use Zoomer

**Use Zoomer like this**

```python
from zoomer import ZmFace
imagePath = sys.argv[1]
face_num_client = ZmFace(imagePath)
face_num_client.face_num()

```