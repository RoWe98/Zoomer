
from setuptools import setup

setup(name='Zoomer',
      version='0.1.0',
      description='Zoomer is an open source face recognition lib',
      url='https://github.com/RoWe98/Zoomer',
      author='RoWe98',
      author_email='wzx8551517@163.com',
      license='MIT',
      packages=['zoomer'])